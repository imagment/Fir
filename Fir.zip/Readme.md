Fir 0.8.5 Beta Version
------------------------------------------------------------------------------------------------------
Welcome to Fir 0.8.5 Beta, developed by Imagment Studios and open-sourced for your enjoyment. We hope you have fun playing! If you have any ideas or suggestions, please feel free to leave a comment.
------------------------------------------------------------------------------------------------------
Upcoming Updates:
------------------------------------------------------------------------------------------------------
0.9.0:
Blindfold Mode
Claiming a Draw / Rules about Draws
General Clean-Up
------------------------------------------------------------------------------------------------------
1.0.0:
Team-Based Game Modes
------------------------------------------------------------------------------------------------------
1.5.0:
More Modifiers
Selection of Minor Rules
------------------------------------------------------------------------------------------------------
2.0.0:
Even More Modifiers!
Badges!
How to Control:
------------------------------------------------------------------------------------------------------
Movement: Use W, A, S, D to move the pointer (the white icon).
Placement: Press Space to place a token at the current pointer location.
Direct Coordinates: Press J and enter coordinates to move the pointer to a specific location.
------------------------------------------------------------------------------------------------------
Time Rules:
There is a time limit for each game, ranging from 300 to 1200 seconds. If a player exceeds the time limit, they receive an additional 50 seconds. However, their tokens on the board will be removed.
------------------------------------------------------------------------------------------------------
Drawing Rules:
To claim a draw, press X. Ensure that all players agree to the draw before confirming.
------------------------------------------------------------------------------------------------------
Abandoning or Resigning:
If you wish to abandon the game or resign, notify all players and confirm the decision to avoid confusion and ensure fair play. If someone abnandoned the game, use Zero key to skip his turn. 
------------------------------------------------------------------------------------------------------
Skipping turn:
If you are willing to skip your turn, press Zero key.
------------------------------------------------------------------------------------------------------
Administrating:
games.txt - It stores Fir rating of all users
user.txt - It stores Fir username of all users
------------------------------------------------------------------------------------------------------